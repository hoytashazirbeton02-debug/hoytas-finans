﻿HOYTAŞ Hazır Beton Finans ve İşletme Yönetimi — v55

v55 OTOMATİK İNTERNET GÜNCELLEMESİ
- Açılışta GitHub Releases üzerinden sessiz sürüm kontrolü yapılır (yayın deposu tanımlandıktan sonra).
- "Güncellemeleri Denetle" düğmesi elle kontrol sağlar; yeni sürüm bulunursa indirme ve kurulum onayı ister.
- İndirilen ZIP SHA-256 özeti doğrulanmadan kurulmaz.
- Kurulum ayrı sürüm klasörüne yapılır; mevcut sürüm ve kullanıcı veritabanı korunur, kurulum öncesi SQLite yedeği alınır.
- İlk yayın için guncelleme_ayarlari.json içindeki github_repo alanına public GitHub deposu owner/repo biçiminde yazılmalıdır.
- GitHub Releases içine HOYTAS adını içeren ZIP paketi ve SHA-256 digest bilgisi eklenmelidir.

HOYTAŞ Hazır Beton Finans ve İşletme Yönetimi — v54

HOYTAŞ Hazır Beton Finans ve İşletme Yönetimi — v47

v42 GELİŞTİRMELER
- Cari hesap ekstresi, gönderdiğiniz örnekteki hesap bilgileri ve sütun düzenine göre hazırlandı.
- PDF ekstresi gerçek PDF olarak oluşturulup kontrol edildi.
- Liste bulunan ana sekmelere tüm sütunlarda çalışan anlık arama eklendi.
- Beton satış kaydı silinirken bağlı tahsilat/kasa/banka/çek yansımaları temizlenir.
- Cari silme işleminden önce otomatik veritabanı yedeği alınır; onayla birlikte carinin bağlı hareket, çek, beton satış ve fatura kayıtları silinir.
- Maaş ödemelerine ayrı Nakit Avans işlem türü eklendi.


v45 RAPOR VE ALTYAPI GÜÇLENDİRMELERİ
- Cari, gelir-gider, çek, beton satış, fatura, alış faturası ve kasa/banka PDF dökümleri birbirinden bağımsızdır; seçilen rapor yalnızca kendi kayıtlarını içerir.
- Beton satış PDF raporunda toplam m³, satış adedi, toplam tutar ve beton cinsine göre m³/tutar özeti bulunur.
- Excel raporunda hem cari bazında hem beton cinsine göre ayrı m³ özet sayfaları vardır.
- v44 veritabanı şema yükseltmesinden önce doğrulanmış ayrı bir güvenlik yedeğine alınır. Yedekler otomatik silinmez.
- SQLite bütünlük kontrolü, FULL senkronizasyon ve bağlantı bekleme süresi ile veri koruması güçlendirildi.
- Ayrıntılar DEGISIKLIKLER_v45.txt dosyasındadır.

KURULUM / GÜNCELLEME
İlk v53 kurulumu:
1. ZIP dosyasını eski programdan farklı yeni bir klasöre tamamen çıkarın.
2. Gerekli Python paketleri eksikse kurulum.bat dosyasını bir kez çalıştırın.
3. Programı doğrudan açmak için yeni klasördeki Baslat.vbs dosyasına çift tıklayın. v69 ile bu dosya kendi klasörünü otomatik tanır; ayrıca Çalıştır düğmesi gerekmez.
4. Masaüstündeki HOYTAŞ simgesini yeni sürüme bağlamak için KISAYOLU_GUNCELLE.bat dosyasını bir kez çalıştırın. Sonrasında masaüstü simgesine çift tıklamanız yeterlidir.

Sonraki sürümlere program içinden geçiş:
1. Yeni HOYTAŞ güncelleme ZIP paketini bilgisayarınıza indirin.
2. Açık HOYTAŞ programında alttaki "Programı Güncelle" düğmesine basıp ZIP dosyasını seçin.
3. Program ZIP'i doğrular, ayrı sürüm klasörüne kurar ve güncelleme öncesi veritabanı yedeği alır.
4. Programı kapatın; masaüstündeki aynı HOYTAŞ simgesine çift tıklayın. Yeni sürüm açılır.
5. Önceki sürüm klasörleri ve veritabanı yedekleri otomatik silinmez.

Not: Program içinden güncelleme paketi yüklenebilir; ancak yeni paketin bilgisayara gelmesi için şimdilik ZIP dosyasının indirilmesi gerekir. Sunucu üzerinde yayın/dağıtım altyapısı kurulduğunda otomatik internetten güncelleme kontrolü de eklenebilir.

ÖNEMLİ VERİ GÜVENLİĞİ
- Eski program klasörünü, hoytas.db dosyasını veya HOYTASFinans\yedekler klasörünü silmeyin/taşımayın.
- Program veritabanını Windows kullanıcı profilindeki %LOCALAPPDATA%\HOYTASFinans\hoytas.db konumunda tutar.
- Yeni sürüm mevcut veritabanını kullanır; şema güncellemeleri kayıtları koruyarak yapılır.
- Cari silme işleminde silmeden önce otomatik yedek oluşturulur.

KISAYOLLAR
- Ctrl+F: Cari Hesaplar sekmesine geçer ve cari arama alanına odaklanır.
- Alt+1, Alt+2, ...: ilgili sekmeye geçer.
- Açık kayıt formunda Enter: Kaydet; Esc: İptal.

DETAYLAR
Tüm değişiklikler DEGISIKLIKLER_v42.txt dosyasındadır.


v44 KISAYOL DUZELTMESI
- Windows Script Host VBS dosyalari UTF-16 LE BOM bicimine cevrildi; 800A0408 gecersiz karakter hatasi giderildi.
- Yeni surum klasorunde KISAYOLU_GUNCELLE.bat dosyasini bir kez calistirin. Masaustu HOYTAS kisayolu sabit kalir ve guncel klasoru acar.
- Eski klasoru ve HOYTASFinans veritabanini silmeyin.

v46 NOTU:
Yedekleme sirasinda Windows WinError 32 dosya kilitlenmesine karsi benzersiz gecici dosya, SQLite butunluk kontrolu ve yeniden deneme mekanizmasi eklendi. Kilitli/gecici yedekler otomatik silinmez. Eski veritabani ve yedek klasorunu silmeyin.


v47 GUNCELLEMESI
- Masaustu kisayolu pythonw/pyw ile gizli baslatilir; CMD/System32 siyah penceresi acik kalmaz. Baslatma hata kaydi LocalAppData\HOYTASFinans\baslatma.log konumundadir.
- Cari PDF/Excel ozetinde toplam beton m3, satis tutari, tahsilat ve kalan bakiye bulunur.
- Cari hareket, beton satis, alinan cek ve verilen cek PDF dokumleri birbirinden bagimsizdir.
- Yeni ZIP'i ayri klasore cikarin ve KISAYOLU_GUNCELLE.bat dosyasini bir kez calistirin. Eski klasoru, veritabanini ve yedekleri silmeyin.


v49 ARAYÜZ YENİLEME
- Daha okunaklı, modern HOYTAŞ renkleri ve geliştirilmiş tablo/sekme görünümü.
- Beton satışında cari araması tek alana alındı; yazdıkça eşleşme önerilir ve tam ünvanla da cari bulunur.
- v48 veritabanı şema sürümü korunur; veritabanı şeması değiştirilmez.
- Ayrıntılar DEGISIKLIKLER_v49.txt dosyasındadır.


v50 CARİ BORÇ UYARILARI
- Ödeme yapılmamış borçlu cariler kırmızı, kısmi ödeme sonrası borcu kalanlar turuncu, borcu kapananlar yeşil gösterilir.
- Ana ekranda açık cari borç toplamı ve hiç tahsilat yapılmamış borçlu cari adedi gösterilir.
- Tahsilat kaydı sonrası uyarılar otomatik güncellenir.
- Ayrıntılar DEGISIKLIKLER_v50.txt dosyasındadır.


v51 CARİ BORÇ TAKİP RAPORU
- Ayrı "Borç Takip" sekmesi eklendi; yalnızca pozitif kalan bakiyesi olan cariler gösterilir.
- Her cari için toplam borç, toplam alacak/tahsilat ve kalan borç ayrı sütunlardadır.
- Kalan borçlu ve kısmi ödeme yapmış cariler renklerle ayrılır; cari adına göre arama yapılır.
- "Borç Listesi PDF Al" düğmesi, tüm borçlu carileri ve toplam kalan cari borcunu tek PDF raporuna aktarır.
- Rapor mevcut cari Borç/Alacak hareketlerinden hesaplanır; yeni tablo/kolon eklenmez ve eski kayıtlar değiştirilmez.
- PDF, mevcut önizleme ve Acrobat açma akışını kullanır.
- Yeni sürümü ayrı klasöre çıkarın; önceki sürüm klasörünü ve veritabanını silmeyin.


v52 BETON SATIŞ AÇIKLAMALARI VE VERİTABANI GÜÇLENDİRMESİ
- Beton satış açıklamaları tek standartta birleştirildi: beton cinsi, m³, m³ birim fiyatı, pompa ücreti/"Pompa yok", toplam bedel, şantiye, ödeme durumu ve not.
- Cari hareket ekranında beton satış borç satırı, satışın tüm ayrıntılarını gösterir.
- Cari ekstresi PDF'si, beton satış PDF'si, cari Excel dökümü ve ana beton satış listesi aynı ayrıntılı açıklamayı kullanır.
- 30,5 m³ gibi küsuratlı miktarlar ana listede, cari dökümünde, PDF ve Excel raporlarında korunur.
- SQLite WAL ve yabancı anahtar kontrolleri bağlantı açılışında doğrulanır; şema yükseltmesi sonrasında bütünlük kontrolü yapılmadan sürüm numarası ilerletilmez.
- Şema sürümü 48 olarak korunur; yeni tablo/kolon eklenmez, mevcut cari ve satış kayıtları değiştirilmez.
- Ayrıntılar DEGISIKLIKLER_v52.txt dosyasındadır.


v53 DOĞRUDAN AÇILIŞ VE PROGRAM İÇİ GÜNCELLEME
- Ayrıntılar DEGISIKLIKLER_v53.txt dosyasındadır.


v54 BETON SATIŞ GİRİŞ DÜZELTMELERİ
- Cari alanında yazma odağını bozan otomatik öneri seçimi kaldırıldı; manuel cari metni serbesttir.
- Beton fiyatı boşsa 0 TL kabul edilir; m³ ve cari ile kayıt yapılabilir.
- Ayrıntılar DEGISIKLIKLER_v54.txt dosyasındadır.


v59 OTOMATİK GÜNCELLEME
- HTTPS manifest, sürüm, SHA-256 ve boş paket doğrulaması güçlendirildi.
- Açılışta yeni sürüm bulunduğunda kurulum öncesi kullanıcı onayı istenir.
- 25 otomatik test başarılıdır.
- Canlı internet güncellemesi için herkese açık HTTPS manifest ve ZIP adresi bir kez tanımlanmalıdır.
- Ayrıntı: YAYIN_SUNUCUSU_KURULUM_v59.txt.


HOYTAŞ v69 NOTU
- Baslat.vbs doğrudan çift tıklamayla açılış için kendi sürüm klasörünü otomatik seçer. Masaüstü sabit başlatıcısı ise aktif sürüm işaretçisini kullanır.
- Gerçek Windows masaüstü testi bu geliştirme ortamında yapılamamıştır; hedef bilgisayarda ilk açılış kontrolü gereklidir.
