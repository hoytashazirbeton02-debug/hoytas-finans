@echo off
chcp 65001 >nul
cd /d "%~dp0"
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m PyInstaller --noconfirm --clean --windowed --onefile --name HOYTASFinans hoytas.py
echo.
echo Islem tamamlandiysa EXE dosyasi dist\HOYTASFinans.exe konumundadir.
pause
