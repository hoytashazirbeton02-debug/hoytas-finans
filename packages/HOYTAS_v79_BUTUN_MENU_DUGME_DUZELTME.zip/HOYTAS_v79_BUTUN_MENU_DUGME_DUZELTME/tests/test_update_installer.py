"""In-app update installer regression tests."""
import importlib.util
import os
import sqlite3
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch

APP = Path(__file__).resolve().parents[1] / "hoytas.py"
spec = importlib.util.spec_from_file_location("hoytas_update_test", APP)
hoytas = importlib.util.module_from_spec(spec)
spec.loader.exec_module(hoytas)


class UpdateInstallerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="hoytas_update_")
        root = Path(self.temp.name)
        hoytas.USER_DATA_DIR = str(root / "user_data")
        hoytas.BACKUP_DIR = str(root / "user_data" / "yedekler")
        hoytas.DB_PATH = str(root / "user_data" / "hoytas.db")
        Path(hoytas.USER_DATA_DIR).mkdir(parents=True)
        with sqlite3.connect(hoytas.DB_PATH) as db:
            db.execute("CREATE TABLE sample (id INTEGER PRIMARY KEY, value TEXT)")
            db.execute("INSERT INTO sample(value) VALUES('korunacak kayıt')")
        self.package = root / "update_v80.zip"
        with zipfile.ZipFile(self.package, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("HOYTAS_Finans_Programi/hoytas.py", "# yeni sürüm\n")
            zf.writestr("HOYTAS_Finans_Programi/Baslat.vbs", "' hidden launcher\n")
            zf.writestr("HOYTAS_Finans_Programi/DEGISIKLIKLER_v80.txt", "v54\n")

    def tearDown(self):
        self.temp.cleanup()

    def test_installs_to_new_version_and_updates_pointer_after_verified_backup(self):
        with patch.object(hoytas.filedialog, "askopenfilename", return_value=str(self.package)), \
             patch.object(hoytas.messagebox, "showinfo") as info, \
             patch.object(hoytas.messagebox, "showerror") as error:
            hoytas.HoytasApp.install_update_package(object())
        error.assert_not_called()
        info.assert_called_once()
        pointer = Path(hoytas.USER_DATA_DIR) / "aktif_program_yolu.txt"
        self.assertTrue(pointer.read_bytes().startswith(b"\xff\xfe"), "VBS uyumlu UTF-16LE BOM bulunmalı")
        target = Path(pointer.read_text(encoding="utf-16"))
        self.assertTrue((target / "hoytas.py").is_file())
        self.assertTrue((target / "Baslat.vbs").is_file())
        self.assertTrue(target.name == "v80")
        backups = list(Path(hoytas.BACKUP_DIR).glob("guncelleme_oncesi_v80_*.db"))
        self.assertEqual(len(backups), 1)
        with sqlite3.connect(backups[0]) as db:
            self.assertEqual(db.execute("SELECT value FROM sample").fetchone()[0], "korunacak kayıt")
        with sqlite3.connect(hoytas.DB_PATH) as db:
            self.assertEqual(db.execute("SELECT value FROM sample").fetchone()[0], "korunacak kayıt")

    def test_rejects_corrupt_package_without_changing_pointer(self):
        bad = Path(self.temp.name) / "bad.zip"
        bad.write_bytes(b"not a zip")
        with patch.object(hoytas.filedialog, "askopenfilename", return_value=str(bad)), \
             patch.object(hoytas.messagebox, "showerror") as error, \
             patch.object(hoytas.messagebox, "showinfo") as info:
            hoytas.HoytasApp.install_update_package(object())
        error.assert_called_once()
        info.assert_not_called()
        self.assertFalse((Path(hoytas.USER_DATA_DIR) / "aktif_program_yolu.txt").exists())

    def test_windows_update_schedules_desktop_shortcut_recreation(self):
        program = Path(self.temp.name) / "program"
        program.mkdir()
        (program / "MASAUSTU_KISAYOLU_OLUSTUR.vbs").write_text("' shortcut helper", encoding="utf-8")
        system_root = Path(self.temp.name) / "Windows"
        (system_root / "System32").mkdir(parents=True)
        wscript = system_root / "System32" / "wscript.exe"
        wscript.write_text("", encoding="ascii")
        with patch.object(hoytas.os, "name", "nt"), \
             patch.dict(os.environ, {"SystemRoot": str(system_root)}), \
             patch.object(hoytas.subprocess, "Popen") as popen:
            hoytas._restore_desktop_shortcut_after_update(str(program))
        popen.assert_called_once()
        args = popen.call_args.args[0]
        self.assertEqual(args[0], str(wscript))
        self.assertEqual(args[-1], "/silent")


if __name__ == "__main__":
    unittest.main()
