import unittest, sqlite3, tempfile, importlib.util
from pathlib import Path
p=Path(__file__).resolve().parents[1]/"hoytas.py"
spec=importlib.util.spec_from_file_location("hoytas_v77",p); app=importlib.util.module_from_spec(spec);spec.loader.exec_module(app)
class AuditTests(unittest.TestCase):
 def setUp(self):
  self.db=sqlite3.connect(":memory:");self.db.executescript(app.SCHEMA)
  self.db.execute("INSERT INTO cari(tur,unvan,created_at) VALUES('Müşteri','Karar','2026-11-17')")
  for qty in [1,84,36,68,105,92]:
   self.db.execute("INSERT INTO beton_satis(tarih,cari_id,beton_cinsi,miktar_m3,birim_fiyat,pompa_ucreti,toplam,odeme_durumu) VALUES('2026-11-17',1,'C35',?,3300,0,?,'Vadeli')",(qty,qty*3300))
  for i,amount in enumerate([3300,0,0,0,0,303600],1):
   self.db.execute("INSERT INTO hareket(tarih,cari_id,tur,kategori,aciklama,tutar) VALUES('2026-11-17',1,'Borç','Satış',?,?)",(f'[SATIŞ:{i}]',amount))
 def tearDown(self):self.db.close()
 def test_detects_four_wrong_amounts_not_missing(self):
  missing,wrong,amb=app.audit_beton_cari_amounts(self.db,1)
  self.assertEqual((len(missing),len(wrong),len(amb)),(0,4,0))
  self.assertEqual(sum(x[2]-x[4] for x in wrong),966900)
 def test_repair_idempotent_and_preserves_existing_ids(self):
  for i in [2,3,4,5]:app.sync_beton_sale_cari_movement(self.db,i)
  self.assertEqual(tuple(len(x) for x in app.audit_beton_cari_amounts(self.db,1)),(0,0,0))
  self.assertEqual(self.db.execute('SELECT count(*) FROM hareket').fetchone()[0],6)
if __name__=='__main__':unittest.main()
