"""Tests for public release update discovery and checksum enforcement."""
import hashlib
import importlib.util
import json
import tempfile
import unittest
from types import SimpleNamespace
from pathlib import Path
from unittest.mock import patch, MagicMock, Mock

APP = Path(__file__).resolve().parents[1] / "hoytas.py"
spec = importlib.util.spec_from_file_location("hoytas_online_update_test", APP)
hoytas = importlib.util.module_from_spec(spec)
spec.loader.exec_module(hoytas)


class OnlineUpdateTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="hoytas_online_")
        self.root = Path(self.temp.name)
        self.config = self.root / "guncelleme_ayarlari.json"
        self.user_dir = self.root / "user_data"
        self.user_dir.mkdir()
        self.config.write_text(json.dumps({"github_repo": "ornek/hoytas"}), encoding="utf-8")
        self.old_config = hoytas.UPDATE_CONFIG_PATH
        self.old_user_dir = hoytas.USER_DATA_DIR
        hoytas.UPDATE_CONFIG_PATH = str(self.config)
        hoytas.USER_DATA_DIR = str(self.user_dir)

    def tearDown(self):
        hoytas.UPDATE_CONFIG_PATH = self.old_config
        hoytas.USER_DATA_DIR = self.old_user_dir
        self.temp.cleanup()

    def test_reads_valid_github_repository(self):
        self.assertEqual(hoytas.HoytasApp._update_config(object()), "ornek/hoytas")

    def test_rejects_invalid_github_repository(self):
        self.config.write_text(json.dumps({"github_repo": "https://example.com/not-a-repo"}), encoding="utf-8")
        self.assertIsNone(hoytas.HoytasApp._update_config(object()))

    def test_no_unverified_default_manifest_is_used_without_github(self):
        app = SimpleNamespace(_check_manifest_update=Mock(), _update_config=lambda: None)
        with patch.object(hoytas.messagebox, "showinfo") as info:
            hoytas.HoytasApp.check_for_updates(app, silent=False)
        app._check_manifest_update.assert_not_called()
        info.assert_called_once()

    def test_https_manifest_downloads_only_after_sha256_validation(self):
        payload = b"manifest update package"
        manifest = {"version": 80, "package_url": "https://cdn.example/hoytas_v73.zip", "sha256": hashlib.sha256(payload).hexdigest()}
        manifest_response = MagicMock()
        manifest_response.__enter__.return_value.read.return_value = json.dumps(manifest).encode()
        package_response = MagicMock()
        package_response.__enter__.return_value.read.side_effect = [payload, b""]
        app = SimpleNamespace(install_update_package=Mock())
        with patch.object(hoytas.urllib.request, "urlopen", side_effect=[manifest_response, package_response]), \
             patch.object(hoytas.messagebox, "askyesno", return_value=True):
            hoytas.HoytasApp._check_manifest_update(app, "https://cdn.example/manifest.json", silent=False)
        app.install_update_package.assert_called_once()
        self.assertEqual(app.install_update_package.call_args.kwargs["source"], "internet")

    def test_v74_client_discovers_v75_release(self):
        payload = b"verified v75 release payload"
        manifest = {"version": 75, "package_url": "https://cdn.example/hoytas_v75.zip", "sha256": hashlib.sha256(payload).hexdigest()}
        manifest_response = MagicMock()
        manifest_response.__enter__.return_value.read.return_value = json.dumps(manifest).encode()
        package_response = MagicMock()
        package_response.__enter__.return_value.read.side_effect = [payload, b""]
        app = SimpleNamespace(install_update_package=Mock())
        with patch.object(hoytas, "APP_VERSION", 74), \
             patch.object(hoytas.urllib.request, "urlopen", side_effect=[manifest_response, package_response]), \
             patch.object(hoytas.messagebox, "askyesno", return_value=True):
            hoytas.HoytasApp._check_manifest_update(app, "https://cdn.example/manifest.json", silent=False)
        app.install_update_package.assert_called_once()

    def test_rejects_wrong_sha256_before_install(self):
        payload = b"tampered update archive bytes"
        release = {
            "tag_name": "v58",
            "assets": [{"name": "HOYTAS_v57.zip", "browser_download_url": "https://example.test/update.zip", "digest": "sha256:" + ("0" * 64)}],
        }
        api_response = MagicMock()
        api_response.__enter__.return_value.read.return_value = json.dumps(release).encode()
        file_response = MagicMock()
        file_response.__enter__.return_value.read.side_effect = [payload, b""]
        app = SimpleNamespace(_update_config=lambda: "ornek/hoytas", install_update_package=Mock())
        with patch.object(hoytas.urllib.request, "urlopen", side_effect=[api_response, file_response]), \
             patch.object(hoytas.messagebox, "askyesno", return_value=True), \
             patch.object(hoytas.messagebox, "showerror") as error:
            hoytas.HoytasApp.check_for_updates(app, silent=False)
        app.install_update_package.assert_not_called()
        error.assert_called_once()


    def test_silent_startup_check_still_asks_before_installing_new_version(self):
        payload = b"safe update payload"
        manifest = {"version": 80, "package_url": "https://cdn.example/hoytas_v73.zip", "sha256": hashlib.sha256(payload).hexdigest()}
        manifest_response = MagicMock()
        manifest_response.__enter__.return_value.read.return_value = json.dumps(manifest).encode()
        package_response = MagicMock()
        package_response.__enter__.return_value.read.side_effect = [payload, b""]
        app = SimpleNamespace(install_update_package=Mock())
        with patch.object(hoytas.urllib.request, "urlopen", side_effect=[manifest_response, package_response]), \
             patch.object(hoytas.messagebox, "askyesno", return_value=False) as ask:
            hoytas.HoytasApp._check_manifest_update(app, "https://cdn.example/manifest.json", silent=True)
        ask.assert_called_once()
        app.install_update_package.assert_not_called()

    def test_manifest_rejects_http_package_url(self):
        manifest = {"version": 80, "package_url": "http://cdn.example/hoytas_v73.zip", "sha256": "a" * 64}
        response = MagicMock()
        response.__enter__.return_value.read.return_value = json.dumps(manifest).encode()
        app = SimpleNamespace()
        with patch.object(hoytas.urllib.request, "urlopen", return_value=response):
            with self.assertRaisesRegex(RuntimeError, "HTTPS"):
                hoytas.HoytasApp._check_manifest_update(app, "https://cdn.example/manifest.json", silent=True)

    def test_manifest_rejects_invalid_version(self):
        manifest = {"version": "latest", "package_url": "https://cdn.example/hoytas.zip", "sha256": "a" * 64}
        response = MagicMock()
        response.__enter__.return_value.read.return_value = json.dumps(manifest).encode()
        app = SimpleNamespace()
        with patch.object(hoytas.urllib.request, "urlopen", return_value=response):
            with self.assertRaisesRegex(RuntimeError, "sürüm numarası"):
                hoytas.HoytasApp._check_manifest_update(app, "https://cdn.example/manifest.json", silent=True)


if __name__ == "__main__":
    unittest.main()
