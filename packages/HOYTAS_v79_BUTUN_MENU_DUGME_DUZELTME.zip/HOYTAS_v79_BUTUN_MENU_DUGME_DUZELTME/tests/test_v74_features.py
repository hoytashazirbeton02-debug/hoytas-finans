import unittest
from pathlib import Path

class Version74Tests(unittest.TestCase):
    def test_selected_cari_pdf_is_linked_to_sale_id(self):
        code = (Path(__file__).resolve().parents[1] / "hoytas.py").read_text()
        start = code.index("    def export_selected_beton_cari_pdf(")
        end = code.index("    def export_beton_cari_sec_pdf(", start)
        section = code[start:end]
        self.assertIn("SELECT cari_id FROM beton_satis WHERE id=?", section)
        self.assertIn("Cari Beton Satış Dökümü", section)
    def test_current_version_is_78(self):
        import hoytas
        self.assertEqual(hoytas.APP_VERSION, 79)
