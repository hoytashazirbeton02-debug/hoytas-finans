"""Regression tests for the shared Cari <-> Beton sale movement."""
import importlib.util
import sqlite3
import tempfile
import unittest
from pathlib import Path

APP = Path(__file__).resolve().parents[1] / "hoytas.py"
spec = importlib.util.spec_from_file_location("hoytas_cari_beton_sync", APP)
hoytas = importlib.util.module_from_spec(spec)
spec.loader.exec_module(hoytas)


class CariBetonSyncTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = sqlite3.connect(Path(self.tmp.name) / "test.db")
        self.db.executescript(hoytas.SCHEMA)
        self.db.execute("INSERT INTO cari(tur,unvan,created_at) VALUES('Müşteri','İlk Cari','2026-11-01')")
        self.db.execute("INSERT INTO cari(tur,unvan,created_at) VALUES('Müşteri','İkinci Cari','2026-11-01')")
        self.db.execute("""INSERT INTO beton_satis(tarih,cari_id,beton_cinsi,miktar_m3,birim_fiyat,
            pompa_ucreti,toplam,odeme_durumu,aciklama)
            VALUES('2026-11-01',1,'C30',10,1000,200,10200,'Vadeli / Tahsil Edilmedi','İlk açıklama')""")
        self.db.commit()

    def tearDown(self):
        self.db.close()
        self.tmp.cleanup()

    def rows(self):
        return self.db.execute("SELECT id,cari_id,tutar,aciklama FROM hareket WHERE kategori='Satış' AND tur='Borç' ORDER BY id").fetchall()

    def test_create_and_edit_sale_updates_same_cari_movement(self):
        first = hoytas.sync_beton_sale_cari_movement(self.db, 1)
        self.db.execute("UPDATE beton_satis SET tarih='2026-11-03',cari_id=2,beton_cinsi='C35',miktar_m3=12.5,birim_fiyat=1100,pompa_ucreti=300,toplam=14050,aciklama='Güncel açıklama' WHERE id=1")
        second = hoytas.sync_beton_sale_cari_movement(self.db, 1)
        self.db.commit()
        rows = self.rows()
        self.assertEqual(first, second)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0][1:3], (2, 14050.0))
        self.assertIn('12.5 m³', rows[0][3])
        self.assertIn('Güncel açıklama', rows[0][3])
        self.assertIn('[SATIŞ:1]', rows[0][3])

    def test_repairs_legacy_row_and_deduplicates_linked_rows(self):
        self.db.execute("INSERT INTO hareket(tarih,cari_id,tur,kategori,aciklama,tutar) VALUES('2026-11-01',1,'Borç','Satış','Beton satış #1 - eski',10200)")
        self.db.execute("INSERT INTO hareket(tarih,cari_id,tur,kategori,aciklama,tutar) VALUES('2026-11-01',1,'Borç','Satış','Kopya [SATIŞ:1]',10200)")
        self.db.commit()
        hoytas.sync_beton_sale_cari_movement(self.db, 1)
        self.db.commit()
        rows = self.rows()
        self.assertEqual(len(rows), 1)
        self.assertIn('[SATIŞ:1]', rows[0][3])

    def test_unassigned_sale_has_no_cari_debit(self):
        self.db.execute("UPDATE beton_satis SET cari_id=NULL WHERE id=1")
        self.db.commit()
        hoytas.sync_beton_sale_cari_movement(self.db, 1)
        self.db.commit()
        self.assertEqual(self.rows(), [])

    def test_cari_name_is_live_through_foreign_key_join(self):
        hoytas.sync_beton_sale_cari_movement(self.db, 1)
        self.db.execute("UPDATE cari SET unvan='Güncel Cari Ünvanı' WHERE id=1")
        name = self.db.execute("SELECT c.unvan FROM beton_satis b JOIN cari c ON c.id=b.cari_id WHERE b.id=1").fetchone()[0]
        self.assertEqual(name, 'Güncel Cari Ünvanı')


if __name__ == '__main__':
    unittest.main()
