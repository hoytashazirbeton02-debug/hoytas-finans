import unittest, sqlite3, tempfile
from pathlib import Path
import importlib.util
spec=importlib.util.spec_from_file_location('hoytas_reconciliation',Path(__file__).resolve().parents[1]/'hoytas.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
class ReconciliationTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.db=sqlite3.connect(Path(self.tmp.name)/'t.db');self.db.executescript(h.SCHEMA)
  self.db.execute("INSERT INTO cari(tur,unvan,created_at) VALUES('Müşteri','Örnek','2026-11-01')")
  self.db.execute("INSERT INTO beton_satis(tarih,cari_id,beton_cinsi,miktar_m3,birim_fiyat,toplam,odeme_durumu) VALUES('2026-11-10',1,'C35',84,3300,277200,'Vadeli')")
 def tearDown(self):self.db.close();self.tmp.cleanup()
 def test_missing_then_linked(self):
  missing,ambiguous=h.find_missing_beton_movements(self.db,1);self.assertEqual(len(missing),1);self.assertFalse(ambiguous)
  h.sync_beton_sale_cari_movement(self.db,1)
  self.assertEqual(h.find_missing_beton_movements(self.db,1),([],[]))
  self.assertEqual(self.db.execute("SELECT tutar FROM hareket WHERE tur='Borç'").fetchone()[0],277200)
 def test_ambiguous_legacy_not_marked_missing(self):
  self.db.execute("INSERT INTO hareket(tarih,cari_id,tur,kategori,aciklama,tutar) VALUES('2026-11-10',1,'Borç','Satış','Eski beton satışı',277200)")
  missing,ambiguous=h.find_missing_beton_movements(self.db,1)
  self.assertFalse(missing);self.assertEqual(len(ambiguous),1)
if __name__=='__main__':unittest.main()
