import unittest
from hoytas import parse_amount
class V72Numbers(unittest.TestCase):
    def test_formats(self):
        for value in ("8 524 130.00", "8.524.130,00", "8,524,130.00", "8\u00a0524\u202f130.00"):
            self.assertEqual(parse_amount(value), 8524130.0)
        self.assertEqual(parse_amount("30,5"), 30.5)
        self.assertEqual(parse_amount("-1.234,56 TL"), -1234.56)
    def test_invalid(self):
        for value in ("1,2,3", "abc", "1.2.34", "", "1e999"):
            with self.assertRaises(ValueError): parse_amount(value)
