"""Regression tests for editable customer search and zero-price concrete sales."""
import importlib.util
import unittest
from pathlib import Path

APP = Path(__file__).resolve().parents[1] / "hoytas.py"
spec = importlib.util.spec_from_file_location("hoytas_beton_entry_test", APP)
hoytas = importlib.util.module_from_spec(spec)
spec.loader.exec_module(hoytas)


class BetonEntryTests(unittest.TestCase):
    def test_customer_suggestions_do_not_replace_manual_text(self):
        options = ["1 - ABC Beton", "2 - Adıyaman İnşaat"]
        typed = "Benim elle yazdığım cari"
        self.assertEqual(hoytas.filter_customer_options(options, typed), [])
        self.assertEqual(typed, "Benim elle yazdığım cari")

    def test_customer_suggestions_filter_without_forcing_selection(self):
        options = ["1 - ABC Beton", "2 - Adıyaman İnşaat"]
        self.assertEqual(hoytas.filter_customer_options(options, "adı"), ["2 - Adıyaman İnşaat"])
        self.assertEqual(hoytas.filter_customer_options(options, ""), options)

    def test_customer_suggestions_match_turkish_diacritics_and_case(self):
        options = ["1 - Adıyaman İnşaat", "2 - Besni Beton"]
        self.assertEqual(hoytas.filter_customer_options(options, "ADIYAMAN"), [options[0]])
        self.assertEqual(hoytas.filter_customer_options(options, "insaat"), [options[0]])

    def test_customer_id_resolution_accepts_id_label_and_exact_turkish_title(self):
        import sqlite3
        db = sqlite3.connect(":memory:")
        db.executescript(hoytas.SCHEMA)
        db.execute("INSERT INTO cari(tur,unvan,created_at) VALUES('Müşteri','Adıyaman İnşaat','2026-11-01')")
        self.assertEqual(hoytas.resolve_customer_id(db, "1 - Adıyaman İnşaat"), 1)
        self.assertEqual(hoytas.resolve_customer_id(db, "ADIYAMAN INSAAT"), 1)
        self.assertIsNone(hoytas.resolve_customer_id(db, "(Cari seçilmedi)"))
        with self.assertRaises(ValueError):
            hoytas.resolve_customer_id(db, "Adıyaman")
        db.close()

    def test_linked_sale_marker_is_detected(self):
        self.assertEqual(hoytas.linked_beton_sale_id("Beton satış 12 [SATIŞ:123]"), 123)
        self.assertIsNone(hoytas.linked_beton_sale_id("Normal cari tahsilatı"))

    def test_m3_only_sale_is_valid_and_posts_zero_total(self):
        self.assertEqual(hoytas.concrete_sale_totals("30,5", "", ""), (30.5, 0.0, 0.0, 0.0))

    def test_price_and_pump_still_calculate_normally(self):
        self.assertEqual(hoytas.concrete_sale_totals("30,5", "1.250,50", "500"), (30.5, 1250.5, 500.0, 38640.25))

    def test_negative_price_is_rejected(self):
        with self.assertRaises(ValueError):
            hoytas.concrete_sale_totals("10", "-1", "0")


if __name__ == "__main__":
    unittest.main()
