"""Regression tests for numeric strings stored/exported in Turkish formats."""
import importlib.util
import unittest
from pathlib import Path

APP = Path(__file__).resolve().parents[1] / "hoytas.py"
spec = importlib.util.spec_from_file_location("hoytas_number_format_test", APP)
hoytas = importlib.util.module_from_spec(spec)
spec.loader.exec_module(hoytas)


class NumberFormatTests(unittest.TestCase):
    def test_spaced_international_thousands_format(self):
        self.assertEqual(hoytas.safe_float("8 524 130.00"), 8524130.00)

    def test_turkish_thousands_and_decimal_format(self):
        self.assertEqual(hoytas.safe_float("8.524.130,00"), 8524130.00)

    def test_nonbreaking_spaces_are_removed(self):
        self.assertEqual(hoytas.safe_float("8\u00a0524\u202f130.00"), 8524130.00)

    def test_decimal_comma(self):
        self.assertEqual(hoytas.safe_float("30,5"), 30.5)

    def test_empty_optional_value_uses_default(self):
        self.assertEqual(hoytas.safe_float("", 0), 0)

    def test_invalid_value_is_not_silently_changed(self):
        with self.assertRaises(ValueError):
            hoytas.safe_float("8x524")


if __name__ == "__main__":
    unittest.main()
