"""HOYTAŞ database upgrade and audit-trail regression tests."""
import importlib.util
from contextlib import closing
import os
import sqlite3
import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path

APP = Path(__file__).resolve().parents[1] / "hoytas.py"
spec = importlib.util.spec_from_file_location("hoytas_under_test", APP)
hoytas = importlib.util.module_from_spec(spec)
spec.loader.exec_module(hoytas)


class DatabaseFoundationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="hoytas_dbtest_")
        root = Path(self.temp.name)
        hoytas.DB_PATH = str(root / "hoytas.db")
        hoytas.BACKUP_DIR = str(root / "backups")
        hoytas.APP_CURRENT_USER = "TestYonetici"

    def tearDown(self):
        self.temp.cleanup()

    def test_upgrade_preserves_existing_records_and_creates_verified_backup(self):
        # Seed a v45 database with existing business data.
        with closing(sqlite3.connect(hoytas.DB_PATH)) as db:
            with db:
                db.executescript(hoytas.SCHEMA)
                db.execute("INSERT INTO cari(tur,unvan,created_at) VALUES('Müşteri','Örnek Hazır Beton','2026-10-30')")
                db.execute("PRAGMA user_version=45")
        with hoytas.connect() as db:
            self.assertEqual(db.execute("PRAGMA user_version").fetchone()[0], 49)
            self.assertEqual(db.execute("SELECT unvan FROM cari WHERE id=1").fetchone()[0], "Örnek Hazır Beton")
            self.assertEqual(db.execute("PRAGMA integrity_check").fetchone()[0], "ok")
        backups = list(Path(hoytas.BACKUP_DIR).glob("*.db"))
        self.assertEqual(len(backups), 1)
        with closing(sqlite3.connect(backups[0])) as backup:
            self.assertEqual(backup.execute("PRAGMA integrity_check").fetchone()[0], "ok")
            self.assertEqual(backup.execute("SELECT unvan FROM cari WHERE id=1").fetchone()[0], "Örnek Hazır Beton")

    def test_audit_triggers_capture_insert_update_delete_and_actor(self):
        with hoytas.connect() as db:
            db.execute("INSERT INTO cari(tur,unvan,created_at) VALUES('Müşteri','İlk Ünvan','2026-10-31')")
            db.execute("UPDATE cari SET unvan='Güncel Ünvan' WHERE id=1")
            db.execute("DELETE FROM cari WHERE id=1")
            rows = db.execute("SELECT actor,table_name,action,record_id,old_values,new_values FROM audit_log ORDER BY id").fetchall()
        self.assertEqual([r[2] for r in rows], ["INSERT", "UPDATE", "DELETE"])
        self.assertTrue(all(r[0] == "TestYonetici" and r[1] == "cari" and r[3] == 1 for r in rows))
        self.assertIn("İlk Ünvan", rows[1][4])
        self.assertIn("Güncel Ünvan", rows[1][5])
        self.assertIn("Güncel Ünvan", rows[2][4])


    def test_cari_statement_is_a_real_pdf_with_turkish_text(self):
        from pypdf import PdfReader
        with hoytas.connect() as db:
            db.execute("INSERT INTO cari(tur,unvan,telefon,vergi_no,created_at) VALUES('Müşteri','Çınar Hazır Beton','05000000000','1234567890','2026-10-31')")
            db.execute("INSERT INTO hareket(tarih,cari_id,tur,kategori,aciklama,tutar,odeme_yontemi) VALUES('2026-10-31',1,'Borç','Beton Satışı','Şantiye beton teslimatı',12500,'Havale')")
            db.execute("INSERT INTO hareket(tarih,cari_id,tur,kategori,aciklama,tutar,odeme_yontemi) VALUES('2026-10-31',1,'Alacak','Tahsilat','Banka tahsilatı',5000,'Banka')")
            db.execute("INSERT INTO beton_satis(tarih,cari_id,miktar_m3,birim_fiyat,toplam,odeme_durumu,beton_cinsi) VALUES('2026-10-31',1,25,500,12500,'Kısmi','C30/37')")
        pdf_path = Path(self.temp.name) / "cari_ekstresi.pdf"
        hoytas.HoytasApp.generate_pdf(None, "Cari Hesap Ekstresi", str(pdf_path), 1)
        raw = pdf_path.read_bytes()
        self.assertTrue(raw.startswith(b"%PDF-"))
        self.assertTrue(raw.rstrip().endswith(b"%%EOF"))
        extracted = "\n".join(page.extract_text() or "" for page in PdfReader(str(pdf_path)).pages)
        self.assertIn("Çınar Hazır Beton", extracted)
        self.assertIn("Toplam Borç", extracted)
        self.assertNotIn("Toplam Beton Satışı", extracted)
        self.assertNotIn("25 m³", extracted)

    def test_independent_financial_reports_generate_separate_valid_pdfs(self):
        from pypdf import PdfReader
        with hoytas.connect() as db:
            db.execute("INSERT INTO cari(tur,unvan,created_at) VALUES('Müşteri','Rapor Cari','2026-10-31')")
            db.execute("INSERT INTO hareket(tarih,cari_id,tur,kategori,aciklama,tutar,odeme_yontemi) VALUES('2026-10-31',1,'Gelir','Tahsilat','Tahsilat kaydı',5000,'Banka')")
            db.execute("INSERT INTO cek(yon,banka,banka_kodu,cari_id,cek_no,kesideci_lehtar,vade,tutar,durum) VALUES('Alınan','Örnek Banka','001',1,'AL-001','Müşteri','2026-11-15',7000,'Bekliyor')")
            db.execute("INSERT INTO cek(yon,banka,banka_kodu,cari_id,cek_no,kesideci_lehtar,vade,tutar,durum) VALUES('Verilen','Diğer Banka','002',1,'VE-002','Tedarikçi','2026-11-20',9000,'Bekliyor')")
            db.execute("INSERT INTO beton_satis(tarih,cari_id,miktar_m3,birim_fiyat,toplam,odeme_durumu,beton_cinsi) VALUES('2026-10-31',1,20,600,12000,'Ödendi','C25/30')")
        reports = ["Cari Hareket Dökümü", "Cari Beton Satış Dökümü", "Gelir-Gider Raporu", "Çek Listesi", "Alınan Çekler Dökümü", "Verilen Çekler Dökümü", "Beton Satış Raporu", "Beton Satışları Dökümü", "Gelen Alış Faturaları", "Kasa ve Banka Raporu"]
        extracted = {}
        for report in reports:
            path = Path(self.temp.name) / (report.replace(" ", "_") + ".pdf")
            hoytas.HoytasApp.generate_pdf(None, report, str(path), 1 if report in ("Cari Hareket Dökümü", "Cari Beton Satış Dökümü") else None)
            data = path.read_bytes()
            self.assertTrue(data.startswith(b"%PDF-"), report)
            self.assertTrue(data.rstrip().endswith(b"%%EOF"), report)
            extracted[report] = "\n".join(page.extract_text() or "" for page in PdfReader(str(path)).pages)
        self.assertIn("AL-001", extracted["Alınan Çekler Dökümü"])
        self.assertNotIn("VE-002", extracted["Alınan Çekler Dökümü"])
        self.assertIn("VE-002", extracted["Verilen Çekler Dökümü"])
        self.assertNotIn("AL-001", extracted["Verilen Çekler Dökümü"])
        self.assertIn("C25/30", extracted["Beton Satışları Dökümü"])
        self.assertIn("Toplam beton miktarı", extracted["Cari Beton Satış Dökümü"])
        self.assertIn("20 m³", extracted["Cari Beton Satış Dökümü"])
        self.assertNotIn("Tahsilat kaydı", extracted["Cari Beton Satış Dökümü"])

    def test_excel_export_opens_and_contains_summary_sheets(self):
        from openpyxl import load_workbook
        with hoytas.connect() as db:
            db.execute("INSERT INTO cari(tur,unvan,created_at) VALUES('Müşteri','Örnek Cari','2026-10-31')")
            db.execute("INSERT INTO beton_satis(tarih,cari_id,miktar_m3,birim_fiyat,toplam,odeme_durumu,beton_cinsi) VALUES('2026-10-31',1,18,600,10800,'Ödendi','C30/37')")
        xlsx_path = Path(self.temp.name) / "hoytas_rapor.xlsx"
        with patch.object(hoytas.filedialog, "asksaveasfilename", return_value=str(xlsx_path)), \
             patch.object(hoytas.messagebox, "showinfo"):
            hoytas.HoytasApp.export_excel(None)
        wb = load_workbook(xlsx_path, read_only=True, data_only=True)
        self.assertIn("Cari Beton m3 Özeti", wb.sheetnames)
        self.assertIn("Beton Cinsi m3 Özeti", wb.sheetnames)
        self.assertEqual(wb["Beton Cinsi m3 Özeti"].cell(2,1).value, "C30/37")
        self.assertEqual(wb["Beton Cinsi m3 Özeti"].cell(2,3).value, 18)
        wb.close()

    def test_debt_followup_pdf_lists_only_positive_cari_balances(self):
        from pypdf import PdfReader
        with hoytas.connect() as db:
            db.execute("INSERT INTO cari(tur,unvan,created_at) VALUES('Müşteri','Kırmızı Beton Ltd.','2026-10-31')")
            db.execute("INSERT INTO cari(tur,unvan,created_at) VALUES('Müşteri','Kısmi Ödeme İnşaat','2026-10-31')")
            db.execute("INSERT INTO cari(tur,unvan,created_at) VALUES('Müşteri','Borcu Kapanan Cari','2026-10-31')")
            db.execute("INSERT INTO hareket(tarih,cari_id,tur,kategori,aciklama,tutar) VALUES('2026-10-31',1,'Borç','Beton','Satış',12500)")
            db.execute("INSERT INTO hareket(tarih,cari_id,tur,kategori,aciklama,tutar) VALUES('2026-11-01',2,'Borç','Beton','Satış',20000)")
            db.execute("INSERT INTO hareket(tarih,cari_id,tur,kategori,aciklama,tutar) VALUES('2026-11-02',2,'Alacak','Tahsilat','Kısmi tahsilat',7500)")
            db.execute("INSERT INTO hareket(tarih,cari_id,tur,kategori,aciklama,tutar) VALUES('2026-11-02',3,'Borç','Beton','Satış',9000)")
            db.execute("INSERT INTO hareket(tarih,cari_id,tur,kategori,aciklama,tutar) VALUES('2026-11-03',3,'Alacak','Tahsilat','Tam tahsilat',9000)")
        rows = hoytas.HoytasApp._debt_rows(None)
        self.assertEqual([r[1] for r in rows], ['Kırmızı Beton Ltd.', 'Kısmi Ödeme İnşaat'])
        self.assertAlmostEqual(rows[0][4], 12500)
        self.assertAlmostEqual(rows[1][4], 12500)
        pdf_path = Path(self.temp.name) / "cari_borc_takip.pdf"
        hoytas.HoytasApp.generate_pdf(None, "Cari Borç Takip Raporu", str(pdf_path))
        self.assertTrue(pdf_path.read_bytes().startswith(b"%PDF-"))
        extracted = "\n".join(page.extract_text() or "" for page in PdfReader(str(pdf_path)).pages)
        self.assertIn("Kırmızı Beton Ltd.", extracted)
        self.assertIn("Kısmi Ödeme İnşaat", extracted)
        self.assertNotIn("Borcu Kapanan Cari", extracted)
        self.assertIn("TOPLAM CARİ BORCU", extracted)
        self.assertIn("25,000.00", extracted)

    def test_beton_sale_description_preserves_fraction_price_pump_site_and_total(self):
        from pypdf import PdfReader
        detail = hoytas.format_beton_aciklama("C30", 30.5, 1200, 2500, 39100,
                                              "Besni Şantiye", "Temel betonu", "Vadeli / Tahsil Edilmedi")
        self.assertIn("30.5 m³", detail)
        self.assertIn("1,200.00 TL/m³", detail)
        self.assertIn("Pompa: 2,500.00 TL (Var)", detail)
        self.assertIn("Toplam: 39,100.00 TL", detail)
        self.assertIn("Besni Şantiye", detail)
        self.assertIn("Temel betonu", detail)
        self.assertEqual(hoytas.format_m3(30.5), "30.5")
        with hoytas.connect() as db:
            db.execute("INSERT INTO cari(tur,unvan,created_at) VALUES('Müşteri','Beton Detay Cari','2026-11-04')")
            db.execute("INSERT INTO santiye(ad) VALUES('Besni Şantiye')")
            db.execute("INSERT INTO beton_satis(tarih,cari_id,santiye_id,beton_cinsi,miktar_m3,birim_fiyat,toplam,pompa_ucreti,odeme_durumu,aciklama) VALUES('2026-11-04',1,1,'C30',30.5,1200,39100,2500,'Vadeli / Tahsil Edilmedi','Temel betonu')")
            db.execute("INSERT INTO hareket(tarih,cari_id,tur,kategori,aciklama,tutar,odeme_yontemi) VALUES('2026-11-04',1,'Borç','Satış','Beton satış • C30 • 30.5 m³ [SATIŞ:1]',39100,'Vadeli')")
        for report in ("Cari Hesap Ekstresi", "Beton Satışları Dökümü"):
            pdf_path = Path(self.temp.name) / (report.replace(" ", "_") + "_detay.pdf")
            hoytas.HoytasApp.generate_pdf(None, report, str(pdf_path), 1 if report == "Cari Hesap Ekstresi" else None)
            extracted = " ".join(" ".join((page.extract_text() or "").split()) for page in PdfReader(str(pdf_path)).pages)
            self.assertIn("30.5 m³", extracted)
            self.assertIn("1,200.00", extracted)
            self.assertIn("2,500.00", extracted)
            self.assertIn("Besni Şantiye", extracted)
            self.assertIn("39,100.00", extracted)

    def test_database_connection_enforces_wal_and_foreign_keys(self):
        with hoytas.connect() as db:
            self.assertEqual(db.execute("PRAGMA foreign_keys").fetchone()[0], 1)
            self.assertEqual(db.execute("PRAGMA journal_mode").fetchone()[0].lower(), "wal")
            self.assertEqual(db.execute("PRAGMA integrity_check").fetchone()[0], "ok")

    def test_database_context_closes_connection_after_commit(self):
        with hoytas.connect() as db:
            db.execute("INSERT INTO cari(tur,unvan,created_at) VALUES('Müşteri','Bağlantı Testi','2026-10-31')")
        with self.assertRaises(sqlite3.ProgrammingError):
            db.execute("SELECT 1")
        with closing(sqlite3.connect(hoytas.DB_PATH)) as check:
            self.assertEqual(check.execute("SELECT COUNT(*) FROM cari").fetchone()[0], 1)

    def test_sensitive_user_table_is_not_audited(self):
        with hoytas.connect() as db:
            db.execute("INSERT INTO kullanici(kullanici_adi,parola_hash,salt,rol) VALUES('test','HASH','SALT','Kullanıcı')")
            count = db.execute("SELECT COUNT(*) FROM audit_log WHERE table_name='kullanici'").fetchone()[0]
        self.assertEqual(count, 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
